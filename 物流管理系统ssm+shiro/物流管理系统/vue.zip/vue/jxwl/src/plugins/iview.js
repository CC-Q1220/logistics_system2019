import Vue from 'vue'
import iView from 'iview'

Vue.use(iView)

import 'iview/dist/styles/iview.css'
