<style>
	html,body,#app{
 height: 100%;
}
</style>

<template>
	
	<div style="height: 100%;">
		<router-link to="/login" ></router-link>
		<router-view></router-view>
	</div>
</template>



