<template>
    <div class="amap-page-container">
     
<div id="container" ></div>
      <div class="toolbar">
        <button @click="add()" id='callApp'>add marker</button>
      </div>
    </div>
  </template>

  <style>
    .amap-demo {
      height: 300px;
    }
  </style>

  <script>
  export default {
      data: function() {
        return {
         
        };
      },
      methods: {
        add() {
          

        }
      },
		created:{
				
			}
    };
</script>