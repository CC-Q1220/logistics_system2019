package com.cchong.logistics.service;

public interface SmsPhone {
    String send(String phone);
}
